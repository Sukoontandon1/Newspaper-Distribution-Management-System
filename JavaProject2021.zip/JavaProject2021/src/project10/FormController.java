package project10;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class FormController {

    @FXML
    void showBillStatus(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project7/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,700);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showCollectBill(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project5/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,550);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showCreateBill(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project4/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,600);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showHawkerList(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project6/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,700);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showPaperList(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,600);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showSetAreas(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project8/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,500);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showSetBuyer(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project3/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,750);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showSetHawker(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project2/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,650);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showViewBuyer(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project9/Form.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Scene scene = new Scene(root1,600,750);
            Stage stage = new Stage();
            stage.setScene(scene);  
            stage.show();
    	} catch(Exception e) {
			e.printStackTrace();
		}
    }
}
