package project9;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button filterArea;

    @FXML
    private Button btnFetch;

    @FXML
    private ComboBox<String> area;

    @FXML
    private TableView<bean> table;

    @FXML
    private ComboBox<String> paper;

    @FXML
    private Button filterBoth;
    
    PreparedStatement pst;
    Connection con;
    ObservableList<bean> list;

    @FXML
    void doFetch(ActionEvent event) {
    	list=FXCollections.observableArrayList();
    	try {
    		pst=con.prepareStatement("select * from customers");
    		ResultSet records=pst.executeQuery();
    		while(records.next())
    		{
    			String nam=records.getString("cname");
    			String addres=records.getString("address");
    			String are=records.getString("area");
    			String hawke=records.getString("hawker");
    			String mobil=records.getString("mobile");
    			String sel_paper=records.getString("sel_papers");
    			bean obj=new bean(nam,addres,are,hawke,mobil,sel_paper);
    			list.add(obj);
    		}
    		table.setItems(list);
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }

    @FXML
    void doFilterArea(ActionEvent event) {
    	list=FXCollections.observableArrayList();
    	try {
    		pst=con.prepareStatement("select * from customers where area=?");
    		pst.setString(1, area.getEditor().getText());
    		ResultSet records=pst.executeQuery();
    		while(records.next())
    		{
    			String nam=records.getString("cname");
    			String addres=records.getString("address");
    			String are=records.getString("area");
    			String hawke=records.getString("hawker");
    			String mobil=records.getString("mobile");
    			String sel_paper=records.getString("sel_papers");
    			bean obj=new bean(nam,addres,are,hawke,mobil,sel_paper);
    			list.add(obj);
    		}
    		table.setItems(list);
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }

    @FXML
    void doFilterBoth(ActionEvent event) {
    	list=FXCollections.observableArrayList();
    	try {
    		pst=con.prepareStatement("select * from customers where area=? and sel_papers like ?");
    		pst.setString(1, area.getEditor().getText());
    		pst.setString(2, "%"+paper.getEditor().getText()+"%");
    		ResultSet records=pst.executeQuery();
    		while(records.next())
    		{
    			String nam=records.getString("cname");
    			String addres=records.getString("address");
    			String are=records.getString("area");
    			String hawke=records.getString("hawker");
    			String mobil=records.getString("mobile");
    			String sel_paper=records.getString("sel_papers");
    			bean obj=new bean(nam,addres,are,hawke,mobil,sel_paper);
    			list.add(obj);
    		}
    		table.setItems(list);
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    @FXML
    void writeExcel(ActionEvent event) {
    	try {
    		Writer writer = null;
        	File file = new File("CustomersFilterBill.csv");
			writer = new BufferedWriter(new FileWriter(file));
			String text="Name,Address,Area,Hawker,Contact,Selected Papers\n";
	        writer.write(text);
	        for (bean p : list)
	        {
				text = p.getName()+ "," + p.getAddress()+ "," + p.getArea()+ "," + p.getHawker()+"," + p.getContact()+ "," + p.getSelPapers()+"\n";
	            writer.write(text);
	        }
	        writer.flush();
	        writer.close();
	        showInfo("One Excel file saved in the Project");
		} catch (Exception e) {
			showWarn("No content in the table");
		}
    }
    
    @SuppressWarnings("unchecked")
	@FXML
    void initialize() {
        assert table != null : "fx:id=\"table\" was not injected: check your FXML file 'Form.fxml'.";
        con=MysqlConnection.getConnection();
        
        TableColumn<bean, String> Name=new TableColumn<bean, String>("Name");
    	Name.setCellValueFactory(new PropertyValueFactory<bean, String>("name"));
    	Name.setMinWidth(98);
    	
    	TableColumn<bean, String> Address=new TableColumn<bean, String>("Address");
    	Address.setCellValueFactory(new PropertyValueFactory<bean, String>("address"));
    	Address.setMinWidth(98);
    	
    	TableColumn<bean, String> Areas=new TableColumn<bean, String>("Areas");
    	Areas.setCellValueFactory(new PropertyValueFactory<bean, String>("area"));
    	Areas.setMinWidth(98);
    	
    	TableColumn<bean, String> Hawker=new TableColumn<bean, String>("Hawker");
    	Hawker.setCellValueFactory(new PropertyValueFactory<bean, String>("hawker"));
    	Hawker.setMinWidth(98);
    	
    	TableColumn<bean, String> Contact=new TableColumn<bean, String>("Contact");
    	Contact.setCellValueFactory(new PropertyValueFactory<bean, String>("contact"));
    	Contact.setMinWidth(98);
    	
    	TableColumn<bean, String> SelectedPapers=new TableColumn<bean, String>("Selected Papers");
    	SelectedPapers.setCellValueFactory(new PropertyValueFactory<bean, String>("selPapers"));
    	SelectedPapers.setMinWidth(98);
    	
    	table.getColumns().addAll(Name,Address,Areas,Hawker,Contact,SelectedPapers);
    	
    	try {
			pst=con.prepareStatement("select * from areas" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String areas=records.getString("area");
				area.getItems().add(areas);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	try {
			pst=con.prepareStatement("select * from papers" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String papers=records.getString("paper");
				paper.getItems().add(papers);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    	
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
