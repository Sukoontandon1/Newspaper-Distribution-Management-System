package project9;

public class bean {
	String name;
	String address;
	String area;
	String hawker;
	String contact;
	String selPapers;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getHawker() {
		return hawker;
	}
	public void setHawker(String hawker) {
		this.hawker = hawker;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getSelPapers() {
		return selPapers;
	}
	public void setSelPapers(String selPapers) {
		this.selPapers = selPapers;
	}
	public bean(String name, String address, String area, String hawker, String contact, String selPapers) {
		super();
		this.name = name;
		this.address = address;
		this.area = area;
		this.hawker = hawker;
		this.contact = contact;
		this.selPapers = selPapers;
	}
	
}
