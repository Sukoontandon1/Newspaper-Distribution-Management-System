package project6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button btnFilter;

    @FXML
    private Button btnFetch;

    @FXML
    private ComboBox<String> area;

    @FXML
    private TableView<bean> table;
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    PreparedStatement pst;
    Connection con;
    ObservableList<bean> list;

    @FXML
    void doFetch(ActionEvent event) {
    	list=FXCollections.observableArrayList();
    	try {
    		pst=con.prepareStatement("select * from hawkers");
    		ResultSet records=pst.executeQuery();
    		while(records.next())
    		{
    			String nam=records.getString("name");
    			String addres=records.getString("address");
    			String contac=records.getString("contact");
    			String area=records.getString("areas");
    			String i=records.getString("id");
    			bean obj=new bean(nam,addres,contac,i,area);
    			list.add(obj);
    		}
    		table.setItems(list);
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    @FXML
    void writeExcel(ActionEvent event) {
    	try {
    		Writer writer = null;
        	File file = new File("Hawkers.csv");
			writer = new BufferedWriter(new FileWriter(file));
			String text="Name,Address,Contact,ID,Areas\n";
	        writer.write(text);
	        for (bean p : list)
	        {
				text = p.getName()+ "," + p.getAddress()+ "," + p.getContact()+ "," + p.getId()+"," + p.getAreas()+"\n";
	            writer.write(text);
	        }
	        writer.flush();
	        writer.close();
	        showInfo("One Excel file saved in the Project");
		} catch (Exception e) {
			showWarn("No content in the table");
		}
    }

    @FXML
    void doFilter(ActionEvent event) {
    	list=FXCollections.observableArrayList();
    	if(area.getEditor().getText()=="")
    		showWarn("Please fill the area");
    	try {
    		pst=con.prepareStatement("select * from hawkers where areas like ?");
    		pst.setString(1, "%"+area.getEditor().getText()+"%");
    		ResultSet records=pst.executeQuery();
    		while(records.next())
    		{
    			String nam=records.getString("name");
    			String addres=records.getString("address");
    			String contac=records.getString("contact");
    			String area=records.getString("areas");
    			String i=records.getString("id");
    			bean obj=new bean(nam,addres,contac,i,area);
    			list.add(obj);
    		}
    		table.setItems(list);
    	} catch (SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    @SuppressWarnings("unchecked")
	@FXML
    void initialize() {
        assert table != null : "fx:id=\"table\" was not injected: check your FXML file 'Form.fxml'.";
        con=MysqlConnection.getConnection();
        
        TableColumn<bean, String> Name=new TableColumn<bean, String>("Name");
    	Name.setCellValueFactory(new PropertyValueFactory<bean, String>("name"));
    	Name.setMinWidth(98);
    	
    	TableColumn<bean, String> Address=new TableColumn<bean, String>("Address");
    	Address.setCellValueFactory(new PropertyValueFactory<bean, String>("address"));
    	Address.setMinWidth(98);
    	
    	TableColumn<bean, String> Contact=new TableColumn<bean, String>("Contact");
    	Contact.setCellValueFactory(new PropertyValueFactory<bean, String>("contact"));
    	Contact.setMinWidth(98);
    	
    	TableColumn<bean, String> IdType=new TableColumn<bean, String>("Id Type");
    	IdType.setCellValueFactory(new PropertyValueFactory<bean, String>("id"));
    	IdType.setMinWidth(98);
    	
    	TableColumn<bean, String> Areas=new TableColumn<bean, String>("Areas");
    	Areas.setCellValueFactory(new PropertyValueFactory<bean, String>("areas"));
    	Areas.setMinWidth(98);
    	
    	table.getColumns().addAll(Name,Address,Contact,IdType,Areas);
    	
    	try {
			pst=con.prepareStatement("select * from areas" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String areas=records.getString("area");
				area.getItems().add(areas);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
