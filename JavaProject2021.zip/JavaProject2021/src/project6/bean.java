package project6;

public class bean {
	String name;
	String address;
	String contact;
	String id;
	String areas;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAreas() {
		return areas;
	}
	public void setAreas(String areas) {
		this.areas = areas;
	}
	public bean(String name, String address, String contact, String id, String areas) {
		super();
		this.name = name;
		this.contact = contact;
		this.address = address;
		this.areas = areas;
		this.id = id;
	}
    
}
