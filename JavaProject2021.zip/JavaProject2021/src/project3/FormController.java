package project3;

import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button btnUpdate;
    
    @FXML
    private Button btnFetch;

    @FXML
    private Button btnSave;

    @FXML
    private TextField address;

    @FXML
    private ComboBox<String> area;

    @FXML
    private ComboBox<String> hawker;

    @FXML
    private TextField contact;

    @FXML
    private DatePicker dos;

    @FXML
    private TextField cname;

    @FXML
    private ListView<String> priceOfPapers;

    @FXML
    private ListView<String> availablePapers;

    @FXML
    private ListView<String> selectedPapers;

    @FXML
    private ListView<String> selectedPapersPrices;

    @FXML
    private Button btnDelete;
    
    Connection con;
	PreparedStatement pst;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}

    @FXML
    void doDelete(ActionEvent event) {
    	try {                                               
			pst=con.prepareStatement("delete from customers where mobile=?");
			pst.setString(1, contact.getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Customer found with this contact number");
			else
				showInfo("Details Deleted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void doSave(ActionEvent event) {
    	try {                                                	
			if(cname.getText()=="")
				showWarn("Please fill the name properly");
			else {
				if(dos.getValue()==null)
				{
					showWarn("Please fill the date");
					return;
				}
				pst=con.prepareStatement("insert into customers values(?,?,?,?,?,?,?,?)");
				pst.setString(1, cname.getText());
				pst.setString(2, address.getText());
				pst.setString(3, area.getEditor().getText());
				pst.setString(4, hawker.getEditor().getText());
				pst.setString(5, contact.getText());
				ObservableList<String> itms=availablePapers.getSelectionModel().getSelectedItems();
		    	ObservableList<Integer> inds=availablePapers.getSelectionModel().getSelectedIndices();
		    	String indxs="";
		    	String items="";
		    	for (Integer integer:inds) 
		    	{
					String st=priceOfPapers.getItems().get(integer);
					indxs=indxs+st+",";
				}
		    	for (String str:itms) 
		    	{
					items=items+str+",";
				}
		    	pst.setString(6, items);
		    	pst.setString(7, indxs);
		    	java.util.Date date=java.util.Date.from(dos.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
				java.sql.Date sqlDate=new java.sql.Date(date.getTime());
				pst.setDate(8, sqlDate);
				pst.executeUpdate();
				showInfo("Details Saved");
			}
		} 
    	catch (SQLException e) {
    		showWarn("Customer with this contact number already exists");
		}
    }

    @FXML
    void doUpdate(ActionEvent event) {
    	try {    
    		if(dos.getValue()==null)
			{
				showWarn("Please fill the date");
				return;
			}
			pst=con.prepareStatement("update customers set cname=?, address=?, area=?, hawker=?, sel_papers=?, sel_prices=?, dos=? where mobile=?");
			pst.setString(1, cname.getText());
			pst.setString(2, address.getText());
			pst.setString(3, area.getEditor().getText());
			pst.setString(4, hawker.getEditor().getText());
			ObservableList<String> itms=availablePapers.getSelectionModel().getSelectedItems();
	    	ObservableList<Integer> inds=availablePapers.getSelectionModel().getSelectedIndices();
	    	String indxs="";
	    	String items="";
	    	for (Integer integer:inds) 
	    	{
				String st=priceOfPapers.getItems().get(integer);
				indxs=indxs+st+",";
			}
	    	for (String str:itms) 
	    	{
				items=items+str+",";
			}
	    	pst.setString(5, items);
	    	pst.setString(6, indxs);
	    	java.util.Date date=java.util.Date.from(dos.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
			java.sql.Date sqlDate=new java.sql.Date(date.getTime());
			pst.setDate(7, sqlDate);
			pst.setString(8, contact.getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Customer found with this contact number");
			else
				showInfo("Details Updated");
			
		} catch (SQLException e) {
	        showWarn("No customer found with this contact number");
		}
    }

    @FXML
    void showHawkers(ActionEvent event) {
    	hawker.getItems().clear();	
		try {
			ArrayList<String> arr=new ArrayList<String>();
			pst=con.prepareStatement("select name from hawkers where areas like ?");
			pst.setString(1, "%"+area.getEditor().getText()+"%");
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String name=records.getString("name");
				arr.add(name);
			}
			for(String str:arr)
	    	{
	    		hawker.getItems().addAll(str);
	    	}
		} catch (Exception e) {
			System.out.println();
		}
    }
    
    @FXML
    void doFetch(ActionEvent event) {
    	try {
			pst=con.prepareStatement("select * from customers where mobile=?");
			pst.setString(1, contact.getText());
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
			    String name=records.getString("cname");
			    String addresss=records.getString("address");
			    String areaa=records.getString("area");
			    String hawkerr=records.getString("hawker");
			    String selPapers=records.getString("sel_papers");
			    String selPrices=records.getString("sel_prices");
				Date date=records.getDate("dos");
			    LocalDate ld=date.toLocalDate();
			    dos.setValue(ld);
			    cname.setText(name);
			    address.setText(addresss);
			    area.setValue(areaa);
			    hawker.setValue(hawkerr);
			    String arr1[]=selPapers.split(",");
			    String arr2[]=selPrices.split(",");
			    selectedPapers.getItems().addAll(arr1);
			    selectedPapersPrices.getItems().addAll(arr2);
			}	
			else
				showWarn("No customer found with this contact number");
		} 
    	catch (SQLException e) {
    		showWarn("No customer found with this contact number");
		}
    }
    
    @FXML
    void initialize() {
    	try {
    		ArrayList<String> arr=new ArrayList<String>();
			pst=con.prepareStatement("select paper from papers");
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String paperName=records.getString("paper");
				arr.add(paperName);
			}
			availablePapers.getItems().addAll(arr);
			availablePapers.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	try {
    		ArrayList<String> ary=new ArrayList<String>();
			pst=con.prepareStatement("select price from papers");
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String price=records.getString("price");
				ary.add(price);
			}
			priceOfPapers.getItems().addAll(ary);
			priceOfPapers.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	try {
			pst=con.prepareStatement("select * from areas" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String areas=records.getString("area");
				area.getItems().add(areas);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    @FXML
    void showPapers(MouseEvent event) {	
		String paper=availablePapers.getSelectionModel().getSelectedItem();
		selectedPapers.getItems().add(paper);
		try {
			pst=con.prepareStatement("select price from papers where paper=?");
			pst.setString(1, paper);
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
				String price=records.getString("price");
				selectedPapersPrices.getItems().add(price);		
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}	
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
