package project;

import javafx.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private ComboBox<String> txtPaperName;

    @FXML
    private TextField txtPaperPrice;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnUpdate;

    Connection con;
	PreparedStatement pst;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}
	
	@FXML
	void doSave() {
		try {                                                	
			if(txtPaperName.getEditor().getText()=="")
				showWarn("Please fill the Paper name properly");
			try {
				pst=con.prepareStatement("insert into papers values(?,?)");
				pst.setString(1, txtPaperName.getEditor().getText());
				pst.setFloat(2, Float.parseFloat(txtPaperPrice.getText()));
				pst.executeUpdate();
				showInfo("Details Saved");
			}
			catch(NumberFormatException e) {
				showWarn("Please input price with digits");
			}
			
		} catch (SQLException e) {
			showWarn("Newspaper with this name already exists, please choose a different name");
		}
	}
    
    @FXML
    void doDelete(ActionEvent event) {
    	try {                                               
			pst=con.prepareStatement("delete from papers where paper=?");
			pst.setString(1, txtPaperName.getEditor().getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Newspaper found with this name");
			else
				showInfo("Details Deleted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void doUpdate(ActionEvent event) {
    	try {                                               
			pst=con.prepareStatement("update papers set price=? where paper=?");
			pst.setFloat(1, Float.parseFloat(txtPaperPrice.getText()));
			pst.setString(2, txtPaperName.getEditor().getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Newspaper found with this name");
			else
				showInfo("Details Updated");
			
		} catch (SQLException e) {
	        showWarn("No Newspaper found with this name");
		}
    }
    
    @FXML
    void initialize() {
    	try {
			pst=con.prepareStatement("select paper from papers" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String paperName=records.getString("paper");
				txtPaperName.getItems().add(paperName);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showPaperName(ActionEvent event) {
    	try {
			pst=con.prepareStatement("select price from papers where paper=?");
			pst.setString(1, txtPaperName.getEditor().getText());
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
				float price=records.getFloat("price");
			    String p=String.valueOf(price);
			    txtPaperPrice.setText(p);
			}	
		} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void showPaperPrice(ActionEvent event) {

    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
