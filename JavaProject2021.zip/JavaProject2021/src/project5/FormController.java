package project5;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button btnPaid;

    @FXML
    private DatePicker dos;

    @FXML
    private TextField contact;

    @FXML
    private Button btnFetch;

    @FXML
    private DatePicker doe;

    @FXML
    private TextField bill;
    
    Connection con;
	PreparedStatement pst;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}

    @FXML
    void doFetch(ActionEvent event) {
    	if(contact.getText()=="")
		{
			showWarn("Please fill the contact number");
		    return;
	    }
    	try {
			pst=con.prepareStatement("select * from bills where mobile=? and status=0");
			pst.setString(1, contact.getText());
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
			    Date dost=records.getDate("dos");
			    LocalDate ld=dost.toLocalDate();
			    dos.setValue(ld);
			    Date doen=records.getDate("doe");
			    LocalDate ld1=doen.toLocalDate();
			    doe.setValue(ld1);
			    Float bil=records.getFloat("bill");
			    bill.setText(String.valueOf(bil));
			}	
			else
				showWarn("No customer found with this contact number");
		} 
    	catch (SQLException e) {
    		showWarn("No customer found with this contact number");
		}
    }

    @FXML
    void doPaid(ActionEvent event) {
    	if(contact.getText()==""||doe.getValue()==null||dos.getValue()==null||bill.getText()=="")
    	{
    		showWarn("Please fill all the details");
    		return;
    	}
    	if(Double.parseDouble(bill.getText().trim())<0.0)
    	{
    		showWarn("Bill amount cannot be negative");
    		return;
    	}
    	try {
			pst=con.prepareStatement("update bills set status=1 where mobile=? and status=0");
			pst.setString(1, contact.getText());
			int count=pst.executeUpdate();
			if(count==1)
			{
				showInfo("Status set to bill paid");
			}
		} catch (SQLException e) {
			showWarn("No customer found with this contact number");
		}
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
