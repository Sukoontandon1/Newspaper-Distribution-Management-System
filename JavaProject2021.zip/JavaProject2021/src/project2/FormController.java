package project2;

import javafx.event.*;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private ComboBox<String> txtName;

    @FXML
    private TextField txtAddress;

    @FXML
    private Button btnUpload;

    @FXML
    private Button btnFetch;

    @FXML
    private TextField txtContact;

    @FXML
    private ComboBox<String> txtArea;

    @FXML
    private TextArea txtAreas;

    @FXML
    private ComboBox<String> txtID;

    @FXML
    private ImageView image;

    @FXML
    private Button btnRemove;

    @FXML
    private Button btnUpdate;

    @FXML
    private Button btnRegister;
    
    @FXML
    private Label path;
    
    Connection con;
	PreparedStatement pst;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}

    @FXML
    void doFetch(ActionEvent event) {
    	try {
			pst=con.prepareStatement("select * from hawkers where name=?");
			pst.setString(1, txtName.getEditor().getText());
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
			    String address=records.getString("address");
			    String contact=records.getString("contact");
			    String areas=records.getString("areas");
			    String picpath=records.getString("pic");
			    String idtype=records.getString("id");
			    txtAddress.setText(address);
			    txtContact.setText(contact);
			    txtAreas.setText(areas);
			    path.setText(picpath);
			    txtID.setPromptText(idtype);
		    	try {
					image.setImage(new Image(new FileInputStream(picpath)));
				} 
		    	catch (FileNotFoundException e) {	
		    		e.printStackTrace();
		    	}
			}	
			else
				showWarn("No Hawker found with this name");
		} 
    	catch (SQLException e) {
    		showWarn("No Hawker found with this name");
		}
    }

    @FXML
    void doRegister(ActionEvent event) {
    	try {                                                	
			if(txtName.getEditor().getText()=="")
				showWarn("Please fill the name properly");
			else {
				pst=con.prepareStatement("insert into hawkers values(?,?,?,?,?,?)");
				pst.setString(1, txtName.getEditor().getText());
				pst.setString(2, txtAddress.getText());
				pst.setString(3, txtContact.getText());
				pst.setString(4, txtAreas.getText());
				pst.setString(5, path.getText());
				pst.setString(6, txtID.getEditor().getText());
				pst.executeUpdate();
				showInfo("Details Saved");
			}
		} 
    	catch (SQLException e) {
    		showWarn("Hawker with this name already exists, please choose a different name");
		}
    }

    @FXML
    void doRemove(ActionEvent event) {
    	try {                                               
			pst=con.prepareStatement("delete from hawkers where name=?");
			pst.setString(1, txtName.getEditor().getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Hawker found with this name");
			else
				showInfo("Details Deleted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void doUpdate(ActionEvent event) {
    	try {     
			pst=con.prepareStatement("update hawkers set address=?, contact=?, areas=?, pic=?, id=? where name=?");
			pst.setString(1, txtAddress.getText());
			pst.setString(2, txtContact.getText());
			pst.setString(3, txtAreas.getText());
			pst.setString(4, path.getText());
			if(txtID.getEditor().getText()=="")
    		{
    			try {
    				pst=con.prepareStatement("select id from hawkers where name=?");
    				pst.setString(1, txtName.getEditor().getText());
    				ResultSet records=pst.executeQuery();
    				if(records.next())
    				{
    					String id=records.getString("id");
    					pst.setString(5, id);
    				}
    	    	} 
    	    	catch (SQLException e) {
    	    		showWarn("No Hawker found with this name");
    			}
    		}
			else	
			    pst.setString(5, txtID.getEditor().getText());
			pst.setString(6, txtName.getEditor().getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No Hawker found with this name");
			else
				showInfo("Details Updated");
			
		} catch (SQLException e) {
	        showWarn("No Hawker found with this name");
		}
    }

    @FXML
    void doUpload(ActionEvent event) {
    	FileChooser chooser=new FileChooser();
    	chooser.setTitle("Select Picture: ");
    	chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png"),
                new FileChooser.ExtensionFilter("*.*", "*.*")
            );
    	File file=chooser.showOpenDialog(null);
    	String filePath=file.getAbsolutePath();
    	path.setText(filePath);
    	try {
			image.setImage(new Image(new FileInputStream(file)));
		} 
    	catch (FileNotFoundException e) {	
    		e.printStackTrace();
    	}
    }
    
    @FXML
    void initialize() {
    	try {
			pst=con.prepareStatement("select name from hawkers" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String Name=records.getString("name");
				txtName.getItems().add(Name);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	try {
			pst=con.prepareStatement("select * from areas" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String area=records.getString("area");
				txtArea.getItems().add(area);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	String ary[]=new String[5];
    	ary[0]="Canadian Passport";
    	ary[1]="Driver's License";
    	ary[2]="Health Card";
    	ary[3]="Foreign Passport";
    	ary[4]="military ID";
    	for(int i=0;i<5;i++)
    	{
    		txtID.getItems().add(ary[i]);
    	}
    	
    	try {
			image.setImage(new Image(new FileInputStream("C:\\Users\\Sukoon\\Downloads\\IDProof.jpg")));
		} 
    	catch (FileNotFoundException e) {	
    		e.printStackTrace();
    	}
    }

    @FXML
    void showArea(ActionEvent event) {
    	String txtar=txtArea.getEditor().getText();
    	if(txtAreas.getText()=="")
    		txtAreas.setText(txtar);
    	else
        txtAreas.setText(txtAreas.getText()+","+txtar);
    }

    @FXML
    void showID(ActionEvent event) {

    }

    @FXML
    void showName(ActionEvent event) {

    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
