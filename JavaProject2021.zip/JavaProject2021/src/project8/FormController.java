package project8;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private ComboBox<String> areas;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnDelete;
    
    Connection con;
	PreparedStatement pst;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}

    @FXML
    void doDelete(ActionEvent event) {
    	try {                                               
			pst=con.prepareStatement("delete from areas where area=?");
			pst.setString(1, areas.getEditor().getText());
			int count=pst.executeUpdate();
			if(count==0)
				showWarn("No such area found");
			else
				showInfo("Details Deleted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void doSave(ActionEvent event) {
    	try {
        	pst=con.prepareStatement("insert into areas values (?)");
			pst.setString(1, areas.getEditor().getText());
		    int count=pst.executeUpdate();
			if(count==1)
				showInfo("Details Saved");
			else
				showWarn("Area with this name already exists");	
		} catch (SQLException e) {
			showWarn("Area with this name already exists");	
		}
    }
    
    @FXML
    void initialize()
    {
    	try {
			pst=con.prepareStatement("select * from areas" );
			ResultSet records=pst.executeQuery();
			while(records.next())
			{
				String area=records.getString("area");
				areas.getItems().add(area);
			}
    	} 
    	catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
