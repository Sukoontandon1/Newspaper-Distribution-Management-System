package project4;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button btnSave;

    @FXML
    private TextField totalPrice;

    @FXML
    private DatePicker dos;

    @FXML
    private TextField contact;

    @FXML
    private Button fetchDate;

    @FXML
    private DatePicker doe;

    @FXML
    private Button btnGenBill;

    @FXML
    private TextField bill;

    Connection con;
	PreparedStatement pst;
	PreparedStatement pst1;
	public FormController() 
	{
		con=MysqlConnection.getConnection();
	}
    
    @FXML
    void doFetchDate(ActionEvent event) {
    	if(contact.getText()=="")
		{
			showWarn("Please fill the contact number");
		    return;
	    }
    	try {
			pst=con.prepareStatement("select dos from customers where mobile=?");
			pst.setString(1, contact.getText());
			ResultSet records=pst.executeQuery();
			if(records.next())
			{
			    Date date=records.getDate("dos");
			    LocalDate ld=date.toLocalDate();
			    dos.setValue(ld);
			}	
			else
				showWarn("No customer found with this contact number");
		} 
    	catch (SQLException e) {
    		showWarn("No customer found with this contact number");
		}
    	
    	try {
			pst1=con.prepareStatement("select * from customers where mobile=?");
			pst1.setString(1, contact.getText());
			ResultSet records=pst1.executeQuery();
			if(records.next())
			{
				String selPrices=records.getString("sel_prices");
				String arr[]=selPrices.split(",");
				double sum=0;
				for(String str:arr)
				{
					if(str!="")
					    sum+=Double.parseDouble(str.trim());
				}
				totalPrice.setText(String.valueOf(sum));
			}
		} catch (SQLException e) {
			showWarn("Please fill the contact number");
		}
    }

    @FXML
    void doGenBill(ActionEvent event) {
    	if(contact.getText()==""||doe.getValue()==null||dos.getValue()==null)
    	{
    		showWarn("Please fill all the contact and dates");
    		return;
    	}
        Period period=Period.between(dos.getValue(), doe.getValue());
        float bil=period.getDays()*Float.parseFloat(totalPrice.getText());
        bill.setText(String.valueOf(bil));
    }

    @FXML
    void doSave(ActionEvent event) {
    	if(contact.getText()==""||doe.getValue()==null||dos.getValue()==null||totalPrice.getText()==""||bill.getText()=="")
    	{
    		showWarn("Please fill all the details");
    		return;
    	}
    	if(Double.parseDouble(bill.getText().trim())<0.0)
    	{
    		showWarn("Bill amount cannot be negative (End date should be after the start date)");
    		return;
    	}
        try {
        	pst1=con.prepareStatement("update customers set dos=? where mobile=?");
			pst1.setDate(1, Date.valueOf(dos.getValue()));
			pst1.setString(2, contact.getText());
		    int count=pst1.executeUpdate();
		    if(count==0)
				showWarn("No Customer found with this contact number");
			pst=con.prepareStatement("insert into bills(mobile,dos,doe,bill) values(?,?,?,?)");
			pst.setString(1, contact.getText());
			pst.setDate(2, Date.valueOf(dos.getValue()));
			pst.setDate(3, Date.valueOf(doe.getValue()));
			pst.setString(4, bill.getText());
			count=pst.executeUpdate();
			if(count==1)
				showInfo("Details Saved");
			else
				showWarn("Please fill the date/dates");	
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
