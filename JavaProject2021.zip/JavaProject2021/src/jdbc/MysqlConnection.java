package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MysqlConnection {
	
	@SuppressWarnings("exports")
	public static Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost/javaproject2021","root","");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		getConnection();
	}

}