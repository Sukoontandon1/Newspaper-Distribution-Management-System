package project7;

public class bean {
	String name;
	String address;
	String area;
	String hawker;
	String mobile;
	String selPapers;
	String selPrices;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getHawker() {
		return hawker;
	}
	public void setHawker(String hawker) {
		this.hawker = hawker;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSelPapers() {
		return selPapers;
	}
	public void setSelPapers(String selPapers) {
		this.selPapers = selPapers;
	}
	public String getSelPrices() {
		return selPrices;
	}
	public void setSelPrices(String selPrices) {
		this.selPrices = selPrices;
	}
	public bean(String name, String address, String area, String hawker, String mobile, String selPapers,
			String selPrices) {
		super();
		this.name = name;
		this.address = address;
		this.area = area;
		this.hawker = hawker;
		this.mobile = mobile;
		this.selPapers = selPapers;
		this.selPrices = selPrices;
	}
    
}
