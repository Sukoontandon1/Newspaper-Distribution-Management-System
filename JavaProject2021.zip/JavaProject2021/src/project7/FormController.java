package project7;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import jdbc.MysqlConnection;

public class FormController {

    @FXML
    private Button btnGetCustomers;

    @FXML
    private TableView<bean> table;

    @FXML
    private RadioButton paidBill;

    @FXML
    private ToggleGroup bill;

    @FXML
    private RadioButton dueBill;
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    PreparedStatement pst;
    Connection con;
    ObservableList<bean> list;

    @FXML
    void ShowCustomers(ActionEvent event) {
    	list=FXCollections.observableArrayList();
        if(paidBill.isSelected())
        {
        	try {
        		pst=con.prepareStatement("select * from customers where mobile in (select mobile from bills where status=1)");
        		ResultSet records=pst.executeQuery();
        		while(records.next())
        		{
        			String nam=records.getString("cname");
        			String addres=records.getString("address");
        			String are=records.getString("area");
        			String hawke=records.getString("hawker");
        			String mobil=records.getString("mobile");
        			String sel_paper=records.getString("sel_papers");
        			String sel_price=records.getString("sel_prices");
        			bean obj=new bean(nam,addres,are,hawke,mobil,sel_paper,sel_price);
        			list.add(obj);
        		}
        		table.setItems(list);
        	} catch (SQLException e) {
        		e.printStackTrace();
        	}
        }
        else if(dueBill.isSelected())
        {
        	try {
        		pst=con.prepareStatement("select * from customers where mobile in (select mobile from bills where status=0)");
        		ResultSet records=pst.executeQuery();
        		while(records.next())
        		{
        			String nam=records.getString("cname");
        			String addres=records.getString("address");
        			String are=records.getString("area");
        			String hawke=records.getString("hawker");
        			String mobil=records.getString("mobile");
        			String sel_paper=records.getString("sel_papers");
        			String sel_price=records.getString("sel_prices");
        			bean obj=new bean(nam,addres,are,hawke,mobil,sel_paper,sel_price);
        			list.add(obj);
        		}
        		table.setItems(list);
        	} catch (SQLException e) {
        		e.printStackTrace();
        	}
        }
        else
        {
        	showWarn("Please select one of the fields");
        }
    }
    
    @FXML
    void writeExcel(ActionEvent event) {
    	try {
    		Writer writer = null;
        	File file = new File("Customers.csv");
			writer = new BufferedWriter(new FileWriter(file));
			String text="Name,Address,Area,Hawker,Contact,Selected Papers,Prices\n";
	        writer.write(text);
	        for (bean p : list)
	        {
				text = p.getName()+ "," + p.getAddress()+ "," + p.getArea()+ "," + p.getHawker()+"," + p.getMobile()+ "," + p.getSelPapers()+ "," + p.getSelPrices()+"\n";
	            writer.write(text);
	        }
	        writer.flush();
	        writer.close();
	        showInfo("One Excel file saved in the Project");
		} catch (Exception e) {
			showWarn("No content in the table");
		}
    }
    
    @SuppressWarnings("unchecked")
	@FXML
    void initialize() {
        assert table != null : "fx:id=\"table\" was not injected: check your FXML file 'Form.fxml'.";
        con=MysqlConnection.getConnection();
        
        TableColumn<bean, String> Name=new TableColumn<bean, String>("Name");
    	Name.setCellValueFactory(new PropertyValueFactory<bean, String>("name"));
    	Name.setMinWidth(98);
    	
    	TableColumn<bean, String> Address=new TableColumn<bean, String>("Address");
    	Address.setCellValueFactory(new PropertyValueFactory<bean, String>("address"));
    	Address.setMinWidth(98);
    	
    	TableColumn<bean, String> Areas=new TableColumn<bean, String>("Areas");
    	Areas.setCellValueFactory(new PropertyValueFactory<bean, String>("area"));
    	Areas.setMinWidth(98);
    	
    	TableColumn<bean, String> Hawker=new TableColumn<bean, String>("Hawker");
    	Hawker.setCellValueFactory(new PropertyValueFactory<bean, String>("hawker"));
    	Hawker.setMinWidth(98);
    	
    	TableColumn<bean, String> Contact=new TableColumn<bean, String>("Contact");
    	Contact.setCellValueFactory(new PropertyValueFactory<bean, String>("mobile"));
    	Contact.setMinWidth(98);
    	
    	TableColumn<bean, String> SelectedPapers=new TableColumn<bean, String>("Selected Papers");
    	SelectedPapers.setCellValueFactory(new PropertyValueFactory<bean, String>("selPapers"));
    	SelectedPapers.setMinWidth(98);
    	
    	TableColumn<bean, String> SelectedPrices=new TableColumn<bean, String>("Prices");
    	SelectedPrices.setCellValueFactory(new PropertyValueFactory<bean, String>("selPrices"));
    	SelectedPrices.setMinWidth(98);
    	
    	table.getColumns().addAll(Name,Address,Areas,Hawker,Contact,SelectedPapers,SelectedPrices);
    	
    }
    
    void showInfo(String msg)
    {
		Alert alert=new Alert(AlertType.INFORMATION);	
		alert.setTitle("Information Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }
    
    void showWarn(String msg)
    {
		Alert alert=new Alert(AlertType.WARNING);	
		alert.setTitle("Warning Dialog");		
		alert.setHeaderText("Please read the below note");
		alert.setContentText(msg);
		alert.showAndWait();
    }

}
