module jsgfx {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	requires java.desktop;
	requires javafx.graphics;
	requires javafx.base;
	exports jdbc;
	exports project;
	exports project2;
	exports project3;
	exports project4;
	exports project5;
	exports project6;
	exports project7;
	exports project8;
	exports project9;
	exports project10;
	opens project to javafx.graphics, javafx.fxml;
	opens project2 to javafx.graphics, javafx.fxml;
	opens project3 to javafx.graphics, javafx.fxml;
	opens project4 to javafx.graphics, javafx.fxml;
	opens project5 to javafx.graphics, javafx.fxml;
	opens project6 to javafx.graphics, javafx.fxml;
	opens project7 to javafx.graphics, javafx.fxml;
	opens project8 to javafx.graphics, javafx.fxml;
	opens project9 to javafx.graphics, javafx.fxml;
	opens project10 to javafx.graphics, javafx.fxml;
}
